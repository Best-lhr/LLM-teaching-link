# RAGOrchestrator.py
from typing import Literal
import logging, time
from HybridTeachingRAG import HybridTeachingRAG
from SegmentTeachingRAG import SegmentTeachingRAG
from macro_retriever import MacroTemplateRetriever          # ←新增

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class TeachingRAGOrchestrator:
    def __init__(
        self,
        encoder_url: str = "http://10.154.22.11:9000",
        reranker_url: str = "http://10.154.22.11:9001",
        knowledge_base_path: str = "knowledge_base",
        timeout: int = 300,
        macro_template_path: str = "macro_template.jsonl"   # ←新增
    ):
        # ---------- 微观 RAG ----------
        self.rags = {
            "segment": SegmentTeachingRAG(
                kb_dir=r"D:\研究生\项目组\科研\小模型+RAG暑期实验\RAG知识库_3",
                encoder_url=encoder_url,
                reranker_url=reranker_url,
            )
        }
        # ---------- 宏观模板 ----------
        self.macro_retriever = MacroTemplateRetriever(
            template_path=macro_template_path,
            encoder_url=encoder_url
        )
        logger.info("RAG系统初始化完成（含宏观模板检索）")

    # ------------------ 供实验调 top-k / 消融 ------------------
    def make_segment_rag(self, k_i, k_f, use_vector=True, use_rerank=True):
        return SegmentTeachingRAG(
            kb_dir=r"D:\研究生\项目组\科研\小模型+RAG暑期实验\RAG知识库_3",
            encoder_url="http://10.154.22.11:9000",
            reranker_url="http://10.154.22.11:9001",
            top_k_initial=k_i,
            top_k_final=k_f,
            use_vector=use_vector,
            use_rerank=use_rerank
        )

    # ------------------ 统一入口 ------------------
    def process(self, query: str, mode: Literal["segment"] = "segment"):
        if mode not in self.rags:
            raise ValueError(f"不支持的RAG模式: {mode}")

        # 1. 宏观模板检索（仅取 top-1）
        macro_tpls = self.macro_retriever.retrieve(query, top_k=1)
        macro_prior = macro_tpls[0] if macro_tpls else None

        # 2. 微观环节检索 + 生成
        start = time.time()
        result = self.rags[mode].retrieve(query, macro_prior=macro_prior)
        logger.info(f"RAG完成，耗时 {time.time()-start:.2f} 秒")
        return result
