# SelfRAG.py
import requests
from typing import List
import logging

logger = logging.getLogger(__name__)

class SelfRAG:
    def __init__(
        self,
        kb_dir: str,
        encoder_url: str,
        top_k: int = 10,
        timeout: int = 300
    ):
        self.kb_dir = kb_dir
        self.encoder_url = encoder_url.rstrip("/")
        self.top_k = top_k
        self.timeout = timeout

    def retrieve(self, query: str) -> List[str]:
        try:
            # 1. 嵌入编码器（params 格式）
            embed_res = requests.post(
                f"{self.encoder_url}/encode",
                params={"text": query},
                timeout=self.timeout
            )
            embed_res.raise_for_status()
            query_vec = embed_res.json()["embedding"]

            # 2. 检索 Top-K（无 rerank）
            search_res = requests.post(
                f"{self.encoder_url}/encode",
                params={
                    "query_embedding": query_vec,
                    "top_k": self.top_k,
                    "index_path": self.kb_dir
                },
                timeout=self.timeout
            )
            search_res.raise_for_status()
            results = search_res.json()["results"]
            return [item["text"] for item in results]

        except Exception as e:
            logger.error(f"SelfRAG检索失败: {e}")
            return []