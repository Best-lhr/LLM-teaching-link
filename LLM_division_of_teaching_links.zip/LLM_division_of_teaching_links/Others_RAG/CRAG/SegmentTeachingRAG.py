# SegmentTeachingRAG.py
import os, re, json, httpx, numpy as np
from typing import List
import time

class SegmentTeachingRAG:
    """
    环节级知识库 RAG
    使用本地 txt 分片 + 服务器 bge + rerank
    接口与 HybridTeachingRAG 完全一致
    """
    def __init__(self,
                 kb_dir: str,
                 encoder_url: str = "http://10.154.22.11:9000",
                 reranker_url: str = "http://10.154.22.11:9001",
                 top_k_initial: int = 10,
                 top_k_final: int = 3):
        self.kb_dir = kb_dir
        self.encoder_url = encoder_url.rstrip("/")
        self.reranker_url = reranker_url.rstrip("/")
        self.top_k_initial = top_k_initial
        self.top_k_final = top_k_final

        # 1. 本地环节级 txt -> [(title, content)]
        self.docs = self._load_segment_docs()
        self.client = httpx.Client(timeout=10)

    # ---------------- 读本地环节级 txt ----------------
    def _load_segment_docs(self) -> List[dict]:
        docs = []
        for fn in os.listdir(self.kb_dir):
            if not fn.endswith(".txt"):
                continue
            path = os.path.join(self.kb_dir, fn)
            with open(path, encoding="utf-8") as f:
                text = f.read().strip()
            # 用【】或空行切
            for block in re.split(r'\n【|\n\n', text):
                if not block.strip():
                    continue
                title = re.search(r'^(.+?)】', '【' + block)
                title = title.group(1) if title else "未命名"
                docs.append({"title": title, "content": block.strip()})
        if not docs:
            raise RuntimeError("环节知识库为空！")
        return docs

    # ---------------- 服务器 embedding ----------------
    def _encode(self, text: str) -> List[float]:
        resp = self.client.post(f"{self.encoder_url}/encode",
                                params={"text": text})
        resp.raise_for_status()
        return resp.json()["embedding"]

    # ---------------- rerank ----------------
    def _rerank(self, query: str, passages: List[str]) -> List[float]:
        resp = self.client.post(f"{self.reranker_url}/v1/rerank",
                                json={"query": query, "documents": passages})
        resp.raise_for_status()
        return resp.json()["scores"]

    # ---------------- 主检索 ----------------
    def retrieve(self, query: str) -> List[str]:
        # 1. 向量粗召回
        query_emb = self._encode(query)
        doc_embs = [self._encode(d["content"]) for d in self.docs]
        sims = [np.dot(query_emb, e) for e in doc_embs]
        cand_idx = np.argsort(sims)[-self.top_k_initial:][::-1]
        candidates = [self.docs[i] for i in cand_idx]

        # 2. rerank 精排
        passages = [d["content"] for d in candidates]
        scores = self._rerank(query, passages)
        reranked = sorted(zip(passages, scores), key=lambda x: x[1], reverse=True)
        final = reranked[:self.top_k_final]

        # 3. 精要回写：标题 + 首句
        results = []
        for content, _ in final:
            title = re.search(r'^【(.+?)】', content)
            title = title.group(1) if title else ""
            first = content.split("。")[0] + "。"
            results.append(f"{title}：{first}")
        #return results
        return "\n".join(results)  # str
