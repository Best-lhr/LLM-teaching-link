# CRAGTeachingRAG.py
import os
import json
import re
import httpx
import numpy as np
from typing import List

class CRAGTeachingRAG:
    """
    2024-09-30 CRAG 风格本地教学环节 Benchmark
    接口与 SegmentTeachingRAG 完全一致
    """
    def __init__(self,
                 kb_dir: str,
                 encoder_url: str = "http://10.154.22.11:9000",
                 reranker_url: str = "http://10.154.22.11:9001",
                 top_k_initial: int = 10,
                 top_k_final: int = 3):
        self.kb_dir = kb_dir
        self.encoder_url = encoder_url.rstrip("/")
        self.reranker_url = reranker_url.rstrip("/")
        self.top_k_initial = top_k_initial
        self.top_k_final = top_k_final
        self.client = httpx.Client(timeout=10)
        self.docs = self._load_docs()

    # 1. 加载本地 txt
    def _load_docs(self) -> List[dict]:
        docs = []
        for fn in os.listdir(self.kb_dir):
            if not fn.endswith('.txt'):
                continue
            path = os.path.join(self.kb_dir, fn)
            with open(path, encoding="utf-8") as f:
                text = f.read().strip()
            # 按环节切
            for block in re.split(r'\n【|\n\n', text):
                if not block.strip():
                    continue
                title = re.search(r'^(.+?)】', '【' + block)
                title = title.group(1) if title else "未命名"
                docs.append({"title": title, "content": block.strip()})
        return docs

    # 2. 编码
    def _encode(self, text: str) -> List[float]:
        resp = self.client.post(f"{self.encoder_url}/encode", params={"text": text})
        resp.raise_for_status()
        return resp.json()["embedding"]

    # 3. rerank
    def _rerank(self, query: str, passages: List[str]) -> List[float]:
        resp = self.client.post(f"{self.reranker_url}/v1/rerank",
                                json={"query": query, "documents": passages})
        resp.raise_for_status()
        return resp.json()["scores"]

    # 4. 主检索
    def retrieve(self, query: str) -> str:
        if not self.docs:
            return ""

        # 向量召回
        query_emb = self._encode(query)
        doc_embs = [self._encode(d["content"]) for d in self.docs]
        sims = [np.dot(query_emb, e) for e in doc_embs]
        cand_idx = np.argsort(sims)[-self.top_k_initial:][::-1]
        candidates = [self.docs[i] for i in cand_idx]

        # rerank
        passages = [d["content"] for d in candidates]
        scores = self._rerank(query, passages)
        reranked = sorted(zip(candidates, scores), key=lambda x: x[1], reverse=True)
        final = reranked[:self.top_k_final]

        # 格式化输出
        results = [f"{d['title']}：{d['content'][:120]}..." for d, _ in final]
        return "\n".join(results)