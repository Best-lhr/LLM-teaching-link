# PIKERAGBenchmarkTeacher.py
import json
import re
from typing import List, Dict
from RAGOrchestrator import TeachingRAGOrchestrator
from openai import OpenAI

class PIKERAGBenchmarkTeacher:
    def __init__(self,
                 rag_orchestrator: TeachingRAGOrchestrator,
                 client: OpenAI,
                 model_path: str,
                 chat_template: str = None):
        self.rag = rag_orchestrator
        self.client = client
        self.model_path = model_path
        self.chat_template = chat_template

    def _llm_generate(self, messages: List[Dict[str, str]]) -> str:
        response = self.client.chat.completions.create(
            model=self.model_path,
            messages=messages,
            temperature=0.3,
            max_tokens=2048,
            extra_body={"chat_template": self.chat_template} if self.chat_template else None
        )
        return response.choices[0].message.content

    def _generate_atomic_queries(self, query: str, context: str) -> List[str]:
        prompt = f"""
你是一个教学任务分解器。
原始问题：{query}
当前上下文：{context}
请根据上下文，将问题分解为最多 3 个原子问题，每个原子问题应能独立从知识库中检索到一个教学环节。
输出格式：
1. <原子问题1>
2. <原子问题2>
3. <原子问题3>
"""
        messages = [{"role": "user", "content": prompt}]
        output = self._llm_generate(messages)
        atomic_queries = re.findall(r'\d+\.\s*(.+)', output)
        return atomic_queries

    def solve_teaching_plan(self, scrambled_text: str) -> str:
        """
        PIKE-RAG 式教学环节还原主流程
        """
        context = ""
        retrieved_chunks = []

        # Step1: 初始原子化问题
        atomic_queries = self._generate_atomic_queries(
            query="请根据教案还原教学环节顺序",
            context=scrambled_text
        )

        for aq in atomic_queries:
            # Step2: RAG 检索
            rag_result = self.rag.process(aq, mode="segment")
            if rag_result:
                retrieved_chunks.append(rag_result)
                context += f"\n【检索结果】{aq}\n{rag_result}"

        # Step3: 最终整合
        final_prompt = f"""
你是一个教学设计师。
原始教案内容：
{scrambled_text}

已检索到的教学环节片段：
{context}

请根据以上信息，**按教学逻辑顺序**还原完整的教学环节，并用【环节名称】标记。
输出格式：
【环节名称】
内容...

要求：
- 每个环节必须完整
- 顺序必须符合教学逻辑
- 不得遗漏内容
"""
        messages = [{"role": "user", "content": final_prompt}]
        return self._llm_generate(messages)