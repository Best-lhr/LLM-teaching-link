# RAGOrchestrator.py
from typing import Literal
import logging
import time
from PikeTeachingRAG import PikeTeachingRAG
from PIKERAG import PIKERAG
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class TeachingRAGOrchestrator:
    def __init__(
        self,
        encoder_url: str = "http://10.154.22.11:9000",
        reranker_url: str = "http://10.154.22.11:9001",
        knowledge_base_path: str = "knowledge_base",
        timeout: int = 300
    ):
        self.rags = {
            # "hybrid": HybridTeachingRAG(
            #     encoder_url=encoder_url.rstrip("/"),
            #     reranker_url=reranker_url.rstrip("/"),
            #     knowledge_base_path=knowledge_base_path,
            #     params={
            #         "top_k_initial": 5,
            #         "top_k_final": 3,
            #         "embedding_timeout": timeout,
            #         "reranker_timeout": timeout,
            #         "embedding_timeout": None,
            #         "reranker_timeout": None  # ← 改为 None
            #     }
            # )

            # "segment": SegmentTeachingRAG(
            #     kb_dir=r"D:\研究生\项目组\科研\小模型+RAG暑期实验\RAG知识库_3",  # 环节级 txt 目录
            #     encoder_url="http://10.154.22.11:9000",
            #     reranker_url="http://10.154.22.11:9001",
            #     top_k_initial=6,  # 可再调小
            #     top_k_final=10
            # ),


            # "pike": PikeTeachingRAG(
            #     kb_dir=r"D:\研究生\项目组\科研\小模型+RAG暑期实验\RAG知识库_3",
            #     encoder_url="http://10.154.22.11:9000",
            #     reranker_url="http://10.154.22.11:9001",
            #     top_k_final=6
            # ),
            "pike": PIKERAG(
                kb_dir=r"D:\研究生\项目组\科研\小模型+RAG暑期实验\RAG知识库_3",
                encoder_url="http://10.154.22.11:9000",
                reranker_url="http://10.154.22.11:9001",
                top_k_initial=6,
                top_k_final=10,
                timeout=timeout
            ),


        }
        logger.info("RAG系统初始化完成")

    def process(self, query: str, mode: str = "hybrid"):
        try:
            start_time = time.time()
            result = self.rags[mode].retrieve(query)
            logger.info(f"RAG完成，耗时 {time.time()-start_time:.2f}秒")
            return result
        except KeyError:
            raise ValueError(f"不支持的RAG模式: {mode}")

