# PIKERAG.py
import requests
from typing import List
import logging

logger = logging.getLogger(__name__)

class PIKERAG:
    def __init__(
        self,
        kb_dir: str,
        encoder_url: str,
        reranker_url: str,
        top_k_initial: int = 6,
        top_k_final: int = 10,
        timeout: int = 300
    ):
        self.kb_dir = kb_dir
        self.encoder_url = encoder_url.rstrip("/")
        self.reranker_url = reranker_url.rstrip("/")
        self.top_k_initial = top_k_initial
        self.top_k_final = top_k_final
        self.timeout = timeout

    def retrieve(self, query: str) -> List[str]:
        try:
            # 1. 嵌入编码器（params 格式）
            embed_res = requests.post(
                f"{self.encoder_url}/encode",
                params={"text": query},
                timeout=self.timeout
            )
            embed_res.raise_for_status()
            query_vec = embed_res.json()["embedding"]

            # 2. 初始检索（Top-K）
            search_res = requests.post(
                f"{self.encoder_url}/encode",
                params={
                    "query_embedding": query_vec,
                    "top_k": self.top_k_initial,
                    "index_path": self.kb_dir
                },
                timeout=self.timeout
            )
            search_res.raise_for_status()
            candidates = search_res.json()["results"]

            # 3. rerank（params + json body）
            rerank_res = requests.post(
                f"{self.reranker_url}/v1/rerank",
                params={"query": query},
                json={"documents": [c["text"] for c in candidates]},
                timeout=self.timeout
            )
            rerank_res.raise_for_status()
            reranked = rerank_res.json()["results"]
            return [item["text"] for item in reranked[:self.top_k_final]]

        except Exception as e:
            logger.error(f"PIKERAG检索失败: {e}")
            return []