# PikeTeachingRAG.py
import os
import json
import logging
import requests
from typing import List

logger = logging.getLogger(__name__)

class PikeTeachingRAG:
    """
    极简 PIKE-RAG 封装，只实现 retrieve 接口。
    假设你已经有一个 PIKE-RAG 后端（REST），
    这里只做转发。
    """
    def __init__(
        self,
        kb_dir: str,
        encoder_url: str = "http://10.154.22.11:9000",
        reranker_url: str = "http://10.154.22.11:9001",
        top_k_final: int = 10,
        timeout: int = 60
    ):
        self.kb_dir = kb_dir
        self.encoder_url = encoder_url.rstrip("/")
        self.reranker_url = reranker_url.rstrip("/")
        self.top_k = top_k_final
        self.timeout = timeout

    def retrieve(self, query: str) -> List[str]:
        """
        调用 PIKE 后端，返回字符串列表。
        如果后端还没搭好，这里可以先返回空列表或 mock。
        """
        payload = {
            "query": query,
            "kb_path": self.kb_dir,
            "top_k": self.top_k
        }
        try:
            resp = requests.post(
                f"{self.encoder_url}/encode",
                params=payload,
                timeout=self.timeout
            )
            resp.raise_for_status()
            return resp.json().get("chunks", [])
        except Exception as e:
            logger.warning("PikeTeachingRAG retrieve error: %s", e)
            return []