# macro_retriever.py
import jsonlines, httpx, numpy as np, os  # ← os 放这里
from typing import List, Dict


class MacroTemplateRetriever:
    """
    教案级模板库检索器
    """

    def __init__(self,
                 template_path: str = "macro_template.jsonl",
                 encoder_url: str = "http://10.154.22.11:9000"):
        print("[DEBUG] 即将加载模板文件：", template_path)
        print("[DEBUG] 文件大小：", os.path.getsize(template_path), "字节")
        self.encoder_url = encoder_url.rstrip("/")
        self.client = httpx.Client(timeout=10)
        # 加载模板 & 预计算嵌入
        self.templates: List[Dict] = []
        self.embeddings: List[List[float]] = []
        with jsonlines.open(template_path) as reader:
            for t in reader:
                self.templates.append(t)
                self.embeddings.append(self._encode(" ".join(t["教学环节及其顺序"])))
        self.embeddings = np.array(self.embeddings)

    def _encode(self, text: str) -> List[float]:
        resp = self.client.post(f"{self.encoder_url}/encode", params={"text": text})
        resp.raise_for_status()
        return resp.json()["embedding"]

    def retrieve(self, query_text: str, top_k: int = 1) -> List[Dict]:
        query_emb = np.array(self._encode(query_text))
        scores = np.dot(self.embeddings, query_emb)
        top_idx = np.argsort(scores)[-top_k:][::-1]
        hits = [self.templates[i] for i in top_idx]

        # ===== 临时可视化（随时删除）=====
        if hits:
            info = {
                "教学模式": hits[0].get("教学模式", ""),
                "课型": hits[0].get("课型", ""),
                "核心概念": hits[0].get("核心概念", ""),
                "教学环节及其顺序": hits[0].get("教学环节及其顺序", []),  # 与 JSON 保持一致
            }
            print(f"[MacroRetriever] 检索结果 -> {info}")
        # ===================================

    def retrieve_exact(self, teaching_mode: str, lesson_type: str, core_concept: str) -> Dict:
        key = f"{teaching_mode}|{lesson_type}|{core_concept}"
        for t in self.templates:
            if key == f"{t.get('教学模式', '')}|{t.get('课型', '')}|{t.get('核心概念', '')}":
                print(f"[MacroRetriever] 精确命中 -> 教学模式={teaching_mode} | 课型={lesson_type} | 核心概念={core_concept}")
                print(f"[MacroRetriever] 教学环节顺序：{' -> '.join(t.get('教学环节及其顺序', []))}")
                return t
        print(f"[MacroRetriever] 未命中宏观模板，返回空字典")
        return {}

        return hits