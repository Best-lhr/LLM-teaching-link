# RAGOrchestrator.py
from typing import Literal, List, Dict
import logging
import joblib
import time
from SegmentTeachingRAG import SegmentTeachingRAG
from macro_retriever import MacroTemplateRetriever

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class TeachingRAGOrchestrator:
    """
    统一入口：微观环节 RAG + 宏观模板精确检索
    process() 返回 (片段文本, 宏观顺序字符串)
    """

    def __init__(
        self,
        encoder_url: str = "http://10.154.22.11:9000",
        reranker_url: str = "http://10.154.22.11:9001",
        macro_template_path: str = "macro_template.jsonl",
        # 三分类器路径（按需修改）
        mode_clf_path: str = r"D:\Python\PythonProject\LLM_division_of_teaching_links\分类模型\无环节乱序训练\k邻近\teachingmode_classifier_cls.pkl",
        type_clf_path: str = r"D:\Python\PythonProject\LLM_division_of_teaching_links\分类模型\无环节乱序训练\k邻近\lessontype_classifier_cls.pkl",
        concept_clf_path: str = r"D:\Python\PythonProject\LLM_division_of_teaching_links\分类模型\无环节乱序训练\k邻近\coreconcept_classifier_cls.pkl",
        kb_dir: str = r"D:\研究生\项目组\科研\小模型+RAG暑期实验\RAG知识库_3"
    ):
        # 1. 微观 RAG
        self.rags = {
            "segment": SegmentTeachingRAG(
                kb_dir=kb_dir,
                encoder_url=encoder_url,
                reranker_url=reranker_url
            )
        }

        # 2. 宏观模板检索器
        self.macro_retriever = MacroTemplateRetriever(
            template_path=macro_template_path,
            encoder_url=encoder_url
        )

        # 3. 加载三分类器
        self.mode_clf = joblib.load(mode_clf_path)
        self.type_clf = joblib.load(type_clf_path)
        self.concept_clf = joblib.load(concept_clf_path)

        logger.info("RAG系统初始化完成（含宏观模板精确检索）")

    # ------------------ 供实验调参 ------------------
    def make_segment_rag(self, k_i: int, k_f: int, use_vector: bool = True, use_rerank: bool = True):
        return SegmentTeachingRAG(
            kb_dir=r"D:\研究生\项目组\科研\小模型+RAG暑期实验\RAG知识库_3",
            encoder_url="http://10.154.22.11:9000",
            reranker_url="http://10.154.22.11:9001",
            top_k_initial=k_i,
            top_k_final=k_f,
            use_vector=use_vector,
            use_rerank=use_rerank
        )

    # ------------------ 统一入口 ------------------
    def process(self, query: str, mode: Literal["segment"] = "segment") -> tuple[str, str]:
        if mode not in self.rags:
            raise ValueError(f"不支持的RAG模式: {mode}")

        # 1. 三分类器预测
        mode_pred = self.mode_clf.predict([query])[0]
        type_pred = self.type_clf.predict([query])[0]
        concept_pred = self.concept_clf.predict([query])[0]

        # 2. 精确匹配宏观模板
        macro_tpl = self.macro_retriever.retrieve_exact(mode_pred, type_pred, concept_pred)
        macro_order = macro_tpl.get("教学环节及其顺序", [])
        macro_prior = {
            "教学模式": mode_pred,
            "课型": type_pred,
            "核心概念": concept_pred,
            "教学环节及其顺序": macro_order
        }

        # 3. 微观环节检索（带先验）
        start = time.time()
        result = self.rags[mode].retrieve(query, macro_prior=macro_prior)
        logger.info(f"RAG完成，耗时 {time.time() - start:.2f} 秒")
        logger.info(f"宏观顺序：{macro_order}")

        # 4. 返回 (片段文本, 宏观顺序字符串)
        return result, " -> ".join(macro_order)