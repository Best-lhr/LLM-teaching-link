from openai import OpenAI

client = OpenAI(base_url="http://10.154.22.11:8000/v1", api_key="sk-xxx")


def analyze_teaching_plan():
    user_input = input("请粘贴完整教案：\n").strip()

    # 直接使用completions接口避免模板问题
    response = client.completions.create(
        #model="/home/lhr/7Bmodel/gemma-2-2b",
        #model="/home/lhr/7Bmodel/gemma-3-4b-it",
        model="/home/lhr/7Bmodel/Chinese-Mistral-7B-Instruct-v0.1",
        #prompt=f"""请你根据输入内容，将其教学环节进行划分。
        prompt=f"""你是一个教学专家，请你根据输入的教案内容，将其教学环节进行划分。
        教案内容：
        {user_input}
        划分结果：""",
        temperature=0.3,
        max_tokens=2000
    )

    print("\n=== 教学环节划分 ===")
    print(response.choices[0].text)


if __name__ == "__main__":
    analyze_teaching_plan()