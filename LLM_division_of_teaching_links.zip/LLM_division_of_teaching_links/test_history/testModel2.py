# -*- coding: utf-8 -*-
from transformers import AutoModelForCausalLM, AutoTokenizer


def load_model(model_path):
    tokenizer = AutoTokenizer.from_pretrained(model_path)
    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        torch_dtype="auto",
        device_map="auto"
    )
    return tokenizer, model


def get_teaching_phases(content, tokenizer, model):
    prompt = f"""请将以下教案内容划分为教学环节，直接输出划分结果，不要任何解释、符号和额外格式：

{content}

教学环节划分："""

    inputs = tokenizer(prompt, return_tensors="pt").to("cuda")
    outputs = model.generate(
        **inputs,
        max_new_tokens=500,
        temperature=0.3,
        do_sample=True,
        pad_token_id=tokenizer.eos_token_id
    )

    full_response = tokenizer.decode(outputs[0], skip_special_tokens=True)
    return full_response.replace(prompt, "").strip()


if __name__ == "__main__":
    model_path = "/home/lhr/7Bmodel/Qwen1.5-4B-Chat"
    #model_path = "/home/lhr/7Bmodel/DeepSeek-R1-Distill-Qwen-1.5B"
    #model_path = "/home/lhr/7Bmodel/Llama-3.2-3B"
    tokenizer, model = load_model(model_path)

    print("请粘贴完整教案内容（粘贴后连续按两次回车键结束输入）：")
    content_lines = []
    empty_line_count = 0

    while True:
        try:
            line = input()
            if line.strip() == "":
                empty_line_count += 1
                if empty_line_count >= 2:  # 连续两个空行结束输入
                    break
            else:
                empty_line_count = 0  # 重置计数器
                content_lines.append(line)
        except EOFError:
            break

    content = "\n".join(content_lines)
    if not content.strip():
        print("错误：输入内容为空")
    else:
        phases = get_teaching_phases(content, tokenizer, model)
        print("\n教学环节划分结果：")
        print(phases)