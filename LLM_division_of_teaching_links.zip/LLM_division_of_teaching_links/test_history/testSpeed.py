import time
import requests

# 测试配置
API_URL = "http://10.154.22.11:8000/v1/completions"
CONCURRENCY = 10  # 并发数
TOTAL_REQUESTS = 100  # 总请求数
PROMPT = "请用中文回答：大语言模型是什么？"  # ~10个tokens

def send_request():
    payload = {
        #"model": "/home/lhr/7Bmodel/DeepSeek-R1-Distill-Qwen-1.5B",
        "model": "/home/lhr/7Bmodel/Qwen1.5-4B-Chat",
        "prompt": PROMPT,
        "max_tokens": 50,
        "temperature": 0.7
    }
    start = time.time()
    response = requests.post(API_URL, json=payload)
    latency = time.time() - start
    return latency, response.status_code == 200

# 运行测试
start_time = time.time()
success_count = 0
total_latency = 0

for _ in range(TOTAL_REQUESTS):
    latency, success = send_request()
    if success:
        success_count += 1
        total_latency += latency

total_time = time.time() - start_time

# 打印结果
print(f"\n测试结果 (共 {TOTAL_REQUESTS} 次请求):")
print(f"成功请求: {success_count} | 失败: {TOTAL_REQUESTS - success_count}")
print(f"总耗时: {total_time:.2f}s")
print(f"吞吐量: {TOTAL_REQUESTS/total_time:.2f} 请求/秒")
print(f"平均延迟: {total_latency/success_count if success_count else 0:.3f}s")