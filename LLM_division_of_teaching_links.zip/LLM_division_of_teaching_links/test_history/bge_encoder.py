from fastapi import FastAPI
from sentence_transformers import SentenceTransformer
import uvicorn

app = FastAPI()
model = SentenceTransformer('/home/lhr/bge-small-zh-v1.5')

@app.post("/encode")
def encode(text: str):
    return {"embedding": model.encode(text).tolist()}

@app.get("/health")
def health_check():
    return {"status": "OK"}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=9000)