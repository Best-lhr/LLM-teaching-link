from openai import OpenAI

client = OpenAI(base_url="http://10.154.22.11:8000/v1", api_key="sk-xxx")

# 一次性输入全部教案
user_input = input("请粘贴完整教案：\n").strip()

response = client.chat.completions.create(
    #model="/home/lhr/7Bmodel/DeepSeek-R1-Distill-Qwen-1.5B",
    model="/home/lhr/7Bmodel/Qwen1.5-4B-Chat",
    #model="/home/lhr/7Bmodel/gemma-3-4b-it",
    #model="/home/lhr/7Bmodel/chatglm3-6b",
    #model="/home/lhr/7Bmodel/Baichuan2-7B-Chat",

    messages=[
        #{"role": "system", "content": "你是一个教学专家，请将教案划分为明确的教学环节。"},
        {"role": "system", "content": "请你根据输入内容，将其教学环节进行划分。"},
        {"role": "user", "content": user_input}
    ],
    temperature=0.3  # 降低随机性，确保划分准确
)

print("\n教学环节划分结果：")
print(response.choices[0].message.content)