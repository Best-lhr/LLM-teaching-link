from fastapi import FastAPI
from sentence_transformers import CrossEncoder
import uvicorn

app = FastAPI()
model = CrossEncoder('/home/lhr/bge-reranker-large')

@app.post("/rerank")
def rerank(query: str, passages: list[str]):
    return {"scores": model.predict([[query, p] for p in passages]).tolist()}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=9001)