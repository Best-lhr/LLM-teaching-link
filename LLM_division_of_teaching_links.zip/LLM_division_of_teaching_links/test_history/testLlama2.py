# -*- coding: utf-8 -*-
from transformers import AutoModelForCausalLM, AutoTokenizer


class LocalModelClient:
    def __init__(self, model_path):
        self.tokenizer = AutoTokenizer.from_pretrained(model_path)
        self.model = AutoModelForCausalLM.from_pretrained(
            model_path,
            torch_dtype="auto",
            device_map="auto"
        )

    def chat_completions_create(self, messages, temperature=0.7, max_length=1000):
        # 构建对话历史
        prompt = ""
        for msg in messages:
            if msg["role"] == "system":
                prompt += f"<|system|>\n{msg['content']}</s>\n"
            elif msg["role"] == "user":
                prompt += f"<|user|>\n{msg['content']}</s>\n"

        # 添加助手响应开头
        prompt += "<|assistant|>\n"

        # 生成响应
        inputs = self.tokenizer(prompt, return_tensors="pt").to("cuda")
        outputs = self.model.generate(
            **inputs,
            max_length=max_length,
            temperature=temperature,
            top_p=0.9,
            do_sample=True,
            pad_token_id=self.tokenizer.eos_token_id
        )

        # 解码并去除输入部分
        full_response = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        response = full_response[len(prompt):].strip()

        return {
            "choices": [{
                "message": {
                    "role": "assistant",
                    "content": response
                }
            }]
        }


# 使用示例
if __name__ == "__main__":
    # 初始化客户端
    client = LocalModelClient("/home/lhr/7Bmodel/Llama-3.2-3B")

    # 获取用户输入
    user_input = input("请粘贴完整教案：\n").strip()

    # 构造消息
    messages = [
        {
            "role": "system",
            "content": "你是一个教学专家，请将输入的内容进行教学环节的划分。"
        },
        {
            "role": "user",
            "content": user_input
        }
    ]

    # 调用模型
    response = client.chat_completions_create(
        messages=messages,
        temperature=0.3,  # 降低随机性
        max_length=1500  # 适当增加长度
    )

    # 输出结果
    print("\n教学环节划分结果：")
    print(response["choices"][0]["message"]["content"])