import os
import re
import json
import numpy as np
import jieba
import jieba.analyse
from fuzzywuzzy import fuzz
from rouge import Rouge
from collections import defaultdict
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from typing import Dict, List, Tuple
from openai import OpenAI

# 初始化客户端
client = OpenAI(base_url="http://10.154.22.11:8000/v1", api_key="EMPTY")

# ================= 模型配置区域 =================
MODELS = {
    #"DeepSeek-R1": "/home/lhr/7Bmodel/DeepSeek-R1-Distill-Qwen-1.5B",
    #"Qwen1.5": "/home/lhr/7Bmodel/Qwen1.5-4B-Chat",
    #"Mistral": "/home/lhr/7Bmodel/Chinese-Mistral-7B-Instruct-v0.1",
    #"ChatGLM3": "/home/lhr/7Bmodel/chatglm3-6b",
    #"Baichuan2": "/home/lhr/7Bmodel/Baichuan2-7B-Chat",
    #"InternLM2-5-7B-Chat-1M": "/home/lhr/7Bmodel/internlm2_5-7b-chat-1m",
    "MiniCPM3-4B": "/home/lhr/7Bmodel/MiniCPM3-4B",
}

# ================= 模板配置（保持原样）=================
MODEL_TEMPLATES = {
    "deepseek": {
        "template": """
        {% if not add_generation_prompt is defined %}
            {% set add_generation_prompt = false %}
        {% endif %}
        {% set ns = namespace(is_first=false, is_tool=false, is_output_first=true, system_prompt='') %}
        {%- for message in messages %}
            {%- if message['role'] == 'system' %}
                {% set ns.system_prompt = message['content'] %}
            {%- endif %}
        {%- endfor %}
        {{bos_token}}{{ns.system_prompt}}
        {%- for message in messages %}
            {%- if message['role'] == 'user' %}
                {%- set ns.is_tool = false -%}
                {{'### ' + message['content']}}
            {%- endif %}
            {%- if message['role'] == 'assistant' and message['content'] is none %}
                {%- set ns.is_tool = false -%}
                {%- for tool in message['tool_calls']%}
                    {%- if not ns.is_first %}
                        {{'### ' + tool['type'] + '\n' + tool['function']['name'] + '\n```json\n' + tool['function']['arguments'] + '\n```\n'}}
                        {%- set ns.is_first = true -%}
                    {%- else %}
                        {{'\n### ' + tool['type'] + '\n' + tool['function']['name'] + '\n```json\n' + tool['function']['arguments'] + '\n```\n'}}
                        {{'### '}}
                    {%- endif %}
                {%- endfor %}
            {%- endif %}
            {%- if message['role'] == 'assistant' and message['content'] is not none %}
                {%- if ns.is_tool %}
                    {{'### ' + message['content'] + '\n'}}
                    {%- set ns.is_tool = false -%}
                {%- else %}
                    {% set content = message['content'] %}
                    {% if '</think>' in content %}
                        {% set content = content.split('</think>')[-1] %}
                    {% endif %}
                    {{'### ' + content + '\n'}}
                {%- endif %}
            {%- endif %}
            {%- if message['role'] == 'tool' %}
                {%- set ns.is_tool = true -%}
                {%- if ns.is_output_first %}
                    {{'### ' + message['content'] + '\n'}}
                    {%- set ns.is_output_first = false %}
                {%- else %}
                    {{'\n### ' + message['content'] + '\n'}}
                {%- endif %}
            {%- endif %}
        {%- endfor -%}
        {% if ns.is_tool %}
            {{'### '}}
        {% endif %}
        {% if add_generation_prompt and not ns.is_tool %}
            {{'### <think>\n'}}
        {% endif %}
        """,
        "keywords": ["deepseek"],
        "features": {
            "supports_tools": True,
            "requires_system_prompt": False,
            "special_tokens": {
                "bos_token": "<|begin_of_text|>",
                "eos_token": "<|end_of_text|>"
            }
        }
    },
    # ... 其他模型模板保持原样 ...
    "qwen": {
        "template": "{% for message in messages %}"
                   "{% if loop.first and messages[0]['role'] != 'system' %}"
                   "{{ '<|im_start|>system\nYou are a helpful assistant.<|im_end|>\n' }}"
                   "{% endif %}"
                   "{{'<|im_start|>' + message['role'] + '\n' + message['content'] + '<|im_end|>' + '\n'}}"
                   "{% endfor %}"
                   "{% if add_generation_prompt %}"
                   "{{ '<|im_start|>assistant\n' }}"
                   "{% endif %}",
        "keywords": ["qwen"],
        "requires_system_prompt": False  # Qwen会自动添加缺省system提示
    },
    "mistral": {
        "template": "{{ bos_token }}"
                    "{% for message in messages %}"
                    "{% if message['role'] == 'user' %}"
                    "{{ '[INST] ' + message['content'] + ' [/INST]' }}"
                    "{% else %}"
                    "{{ message['content'] + eos_token }}"
                    "{% endif %}"
                    "{% endfor %}",
        "keywords": ["mistral"]
    },
    "chatglm": {
        "template": "{% for message in messages %}"
                    "{{'<|im_start|>' + message['role'] + '\n' + message['content'] + '<|im_end|>' + '\n'}}"
                    "{% endfor %}",
        "keywords": ["chatglm"]
    },
    "baichuan": {
        "template": "{{ bos_token }}"
                    "{% for message in messages %}"
                    "{% if message['role'] == 'user' %}"
                    "{{ '<reserved_106>' + message['content'] + '<reserved_107>' }}"
                    "{% else %}"
                    "{{ message['content'] + eos_token }}"
                    "{% endif %}"
                    "{% endfor %}",
        "keywords": ["baichuan"]
    },
    "internlm": {
        "template": "{% for message in messages %}"
                    "<|im_start|>{{message['role']}}\n{{message['content']}}<|im_end|>\n"
                    "{% endfor %}",
        "keywords": ["internlm"]
    },
    "minicpm": {
        "template": "{% for message in messages %}"
                    "<|im_start|>{{message['role']}}\n{{message['content']}}<|im_end|>\n"
                    "{% endfor %}",
        "keywords": ["minicpm"]
    }
}

def detect_model_type(model_path):
    """自动检测模型类型（原逻辑未修改）"""
    model_path = model_path.lower()
    for model_type, config in MODEL_TEMPLATES.items():
        if any(kw in model_path for kw in config["keywords"]):
            return model_type
    return "mistral"


# ================= 新增评估模块 =================
class LessonPlanEvaluator:
    def __init__(self, gt_json_path: str):
        """初始化评估器"""
        with open(gt_json_path, 'r', encoding='utf-8') as f:
            self.gt_data = json.load(f)
        self.rouge = Rouge()
        jieba.initialize()

        # 教学环节关键词库
        self.pedagogy_keywords = {
            "导入": ["引导", "情境", "兴趣", "提问", "启发"],
            "讲解": ["概念", "原理", "示范", "解释", "分析"],
            "练习": ["操作", "应用", "实践", "训练", "完成"],
            "总结": ["回顾", "要点", "强调", "归纳", "梳理"]
        }

    def _parse_sections(self, text: str) -> Dict[str, str]:
        """增强版的环节解析（支持更多格式变体）"""
        sections = {}
        current_section = None

        # 支持多种标记格式：【环节名称】、[环节名称]、环节名称：
        section_pattern = re.compile(r'^([【\[《])(.+?)([】\]》])$|^(.*?:)$')

        for line in text.split('\n'):
            line = line.strip()
            if not line:
                continue

            # 尝试匹配环节名称
            match = section_pattern.match(line)
            if match:
                # 提取环节名称（兼容【A】或 A: 等形式）
                current_section = match.group(2) if match.group(2) else match.group(4).rstrip(':')
                sections[current_section] = ""
            elif current_section:
                sections[current_section] += line + "\n"

        return {k: v.strip() for k, v in sections.items() if k and v}

    def evaluate(self, pred_text: str, filename: str) -> Dict[str, float]:
        """执行完整评估流程"""
        pred_sections = self._parse_sections(pred_text)
        gt_sections = self.gt_data.get(filename, {})

        if not gt_sections:
            return {"error": "未找到对应的标准答案"}

        # 计算各项指标
        metrics = {
            "内容完整性": self._content_completeness(pred_sections, gt_sections),
            #"教学逻辑性": self._pedagogical_quality(pred_sections),
            #"环节连贯性": self._section_coherence(pred_sections),
            #"语言流畅度": self._language_fluency(pred_sections),
            "顺序合理性": self._order_consistency(pred_sections, gt_sections),
            #"关键词覆盖度": self._keyword_coverage(pred_sections, gt_sections)
        }

        # 计算综合评分（加权平均）
        weights = {
            "内容完整性": 0.6,
            #"教学逻辑性": 0.25,
            #"环节连贯性": 0.15,
            #"语言流畅度": 0.1,
            "顺序合理性": 0.4,
            #"关键词覆盖度": 0.1
        }
        metrics["综合评分"] = sum(metrics[k] * weights[k] for k in metrics)

        return {k: round(v, 4) for k, v in metrics.items()}


#内容完整性
    def _content_completeness(self, pred: Dict[str, str], gt: Dict[str, str]) -> float:
        scores = []
        pred_contents = list(pred.values())  # 所有预测的内容

        for gt_content in gt.values():
            # 计算当前gt_content与所有预测内容的最佳匹配分
            best_score = max([
                self.rouge.get_scores(pred_content, gt_content)[0]['rouge-l']['f']
                for pred_content in pred_contents
            ], default=0.0)
            scores.append(best_score)

        return np.mean(scores)

# 顺序合理性
    def _order_consistency(self, pred: Dict[str, str], gt: Dict[str, str]) -> float:
        """顺序合理性性评估"""
        pred_texts = [text for text in pred.values() if text.strip()]  # 过滤空文本
        gt_texts = [text for text in gt.values() if text.strip()]  # 过滤空文本

        if not pred_texts or not gt_texts:
            return 0.5  # 如果 pred 或 gt 无有效内容，返回中性值

        # 放宽 TF-IDF 词过滤（允许单字词，禁用停用词过滤）
        vectorizer = TfidfVectorizer(
            token_pattern=r"(?u)\b\w+\b",  # 允许单字词
            stop_words=None,  # 禁用停用词过滤
            min_df=1  # 允许所有词
        )

        try:
            pred_matrix = vectorizer.fit_transform(pred_texts)
            gt_matrix = vectorizer.transform(gt_texts)

            # 计算相似度矩阵
            sim_matrix = cosine_similarity(pred_matrix, gt_matrix)
            matched_indices = np.argmax(sim_matrix, axis=1)

            # 检查顺序一致性
            correct = 0
            for i in range(len(matched_indices) - 1):
                if matched_indices[i] < matched_indices[i + 1]:
                    correct += 1

            return correct / (len(matched_indices) - 1) if len(matched_indices) > 1 else 0.5
        except ValueError:
            return 0.5  # 如果仍然出错，返回中性值

#环节边界F1
    def _boundary_f1_json(pred_text: str, gt_sections: Dict[str, Dict]) -> float:
        """
        直接基于teaching_plan.json中的位置信息计算边界F1
        :param gt_sections: 从json加载的字典，需包含start_pos/end_pos
        """
        # 1. 提取预测边界（模型输出的环节标记位置）
        pred_boundaries = set()
        for match in re.finditer(r'[【\[](.+?)[】\]]', pred_text):
            pred_boundaries.add(match.start())  # 记录环节标记的起始位置

        # 2. 提取真实边界（从json中读取）
        gt_boundaries = set()
        for section_info in gt_sections.values():
            gt_boundaries.add(section_info["start_pos"])  # 添加每个环节的起始位置

        # 3. 计算F1（允许±10字符的容错）
        tp = fp = fn = 0
        for p_pos in pred_boundaries:
            if any(abs(p_pos - g_pos) <= 10 for g_pos in gt_boundaries):
                tp += 1
            else:
                fp += 1
        for g_pos in gt_boundaries:
            if not any(abs(p_pos - g_pos) <= 10 for p_pos in pred_boundaries):
                fn += 1

        precision = tp / (tp + fp) if (tp + fp) > 0 else 0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0
        return 2 * (precision * recall) / (precision + recall + 1e-8)


#环节名称规范性
    def _section_name_soft(pred_sections: Dict[str, str], gt_sections: Dict[str, str]) -> float:
        """基于teaching_plan.json的模糊名称匹配"""
        # 直接从gt_sections提取标准名称（如teaching_plan.json中的"导入"、"讲解"等）
        standard_names = list(gt_sections.keys())  # 直接使用标准答案的环节名称

        matched_scores = []
        for pred_name in pred_sections.keys():
            max_score = max(
                fuzz.partial_ratio(pred_name, std_name)
                for std_name in standard_names
            )
            matched_scores.append(max_score / 100)

        # 动态数量适配（惩罚过多或过少环节）
        ratio = min(len(pred_sections) / len(gt_sections), 1.0)
        return ratio * np.mean(matched_scores) if matched_scores else 0

# #教学逻辑性
#     def _pedagogical_quality(self, sections: Dict[str, str]) -> float:
#         total_score = 0
#         valid_sections = 0
#
#         for name, content in sections.items():
#             max_section_score = 0  # 记录当前环节的最高匹配分
#
#             # 检查环节名称是否模糊匹配教学环节（如 "导入" ≈ "课堂引入"）
#             for section_type, keywords in self.pedagogy_keywords.items():
#                 # 1. 名称模糊匹配（阈值可调，如 70）
#                 name_similarity = fuzz.ratio(section_type, name)
#                 if name_similarity > 50:
#                     # 2. 检查内容是否包含该环节的关键词
#                     content_matches = sum(1 for kw in keywords if kw in content)
#                     section_score = content_matches / len(keywords)
#                     max_section_score = max(max_section_score, section_score)
#
#             # 如果名称完全不匹配，但内容符合某个环节的关键词，仍然给分
#             if max_section_score == 0:
#                 for section_type, keywords in self.pedagogy_keywords.items():
#                     content_matches = sum(1 for kw in keywords if kw in content)
#                     section_score = content_matches / len(keywords) * 0.8  # 适当降权（如 0.8）
#                     max_section_score = max(max_section_score, section_score)
#
#             total_score += max_section_score
#             valid_sections += 1
#
#         return total_score / valid_sections if valid_sections else 0.7
#
# #环节连贯性
#     def _section_coherence(self, sections: Dict[str, str]) -> float:
#         """环节间语义连贯性"""
#         texts = [" ".join(jieba.cut(v)) for v in sections.values()]
#         if len(texts) < 2:
#             return 0.8  # 单个环节默认较高分
#
#         try:
#             tfidf = TfidfVectorizer().fit_transform(texts)
#             sim_matrix = cosine_similarity(tfidf)
#             np.fill_diagonal(sim_matrix, 0)
#             return np.mean(sim_matrix)
#         except:
#             return 0.6  # 异常情况返回中间值
#
# #语言流畅度
#     def _language_fluency(self, sections: Dict[str, str]) -> float:
#         """语言表达流畅度"""
#         all_text = " ".join(sections.values())
#         words = list(jieba.cut(all_text))
#         unique_words = set(words)
#
#         # 计算重复率（反向指标）
#         repeat_ratio = 1 - len(unique_words) / len(words) if words else 0
#         # 转换为正向评分（重复率越低分越高）
#         return max(0.7, 1 - repeat_ratio * 2)  # 保证基础分在0.7以上
#
#
#
# #关键词覆盖度
#     def _keyword_coverage(self, pred: Dict[str, str], gt: Dict[str, str]) -> float:
#         """教学关键词覆盖度"""
#         # 提取标准答案中的关键词
#         gt_keywords = set()
#         for content in gt.values():
#             gt_keywords.update(jieba.analyse.extract_tags(content, topK=15))
#
#         if not gt_keywords:
#             return 0.5
#
#         # 计算覆盖率
#         covered = 0
#         for content in pred.values():
#             content_keywords = set(jieba.analyse.extract_tags(content, topK=20))
#             covered += len(gt_keywords & content_keywords)
#
#         return min(1.0, covered / len(gt_keywords))


# ================= 增强版批处理函数 =================
def batch_process_with_eval(input_folder: str,
                            output_folder: str,
                            gt_json_path: str):
    """带评估的批量处理函数（优化版）"""
    evaluator = LessonPlanEvaluator(gt_json_path)

    for model_name, model_path in MODELS.items():
        print(f"\n=== 开始测试模型: {model_name} ===")
        model_output_dir = os.path.join(output_folder, model_name)
        os.makedirs(model_output_dir, exist_ok=True)

        all_metrics = {}
        file_count = 0
        success_count = 0

        for filename in sorted(os.listdir(input_folder)):
            if not filename.endswith('.txt'):
                continue

            file_count += 1
            print(f"\n处理文件 {file_count}: {filename}")

            # 处理单个文件
            input_path = os.path.join(input_folder, filename)
            with open(input_path, 'r', encoding='utf-8') as f:
                content = f.read().strip()

            # 使用模板系统进行推理
            model_type = detect_model_type(model_path)

            # messages = [
            #     {
            #         "role": "system",
            #         "content": "你是一个资深教学设计师，请严格完成以下任务：\n"
            #                    "1. 识别教案中的所有教学环节\n"
            #                    "2. 对每个环节必须输出：【环节名称】和对应的完整教学内容\n"
            #                    "3. 保持内容原封不动，仅添加环节标记\n\n"
            #                    "输出格式要求：\n"
            #                    "【环节名称】\n"
            #                    "该环节的完整内容（包括所有文字、标点等原始内容）\n\n"
            #                    "示例：\n"
            #                    "【课堂导入】\n"
            #                    "同学们，今天我们学习...（此处为完整的导入部分内容）"
            #     },
            #     {
            #         "role": "user",
            #         "content": f"请分析以下教案并划分教学环节（严格按上述要求输出）：\n{content}"
            #     }
            # ]

            messages = [
                {
                    "role": "system",
                    "content": "你是一个资深教学设计师，请严格完成以下任务：\n"
                               "1. 识别教案中所有教学环节，并**按原始正确顺序**划分\n"
                               "2. 每个环节必须包含：【环节名称】和对应的完整教学内容\n"
                               "3. 环节名称需符合标准教学术语（如导入、讲解、练习、总结）\n"
                               "4. 保持内容原封不动，仅添加环节标记\n\n"
                               "**顺序复原规则**：\n"
                               "- 若教案环节顺序被打乱（如练习出现在导入前），需按教学逻辑复原\n"
                               "- 常见教学流程：导入 → 讲解 → 练习 → 总结 → 作业\n\n"
                               "输出格式要求：\n"
                               "【环节名称】\n"
                               "该环节的完整内容（包括所有文字、标点等原始内容）\n\n"
                               "示例：\n"
                               "【课堂导入】\n"
                               "同学们，今天我们学习...（此处为完整的导入部分内容）\n"
                               "【知识讲解】\n"
                               "分数由分子和分母组成..."
                },
                {
                    "role": "user",
                    "content": f"请分析以下教案并划分教学环节（需复原正确顺序）：\n{content}"
                }
            ]

            try:
                response = client.chat.completions.create(
                    model=model_path,
                    messages=messages,
                    temperature=0.3,
                    max_tokens=2048,
                    extra_body={"chat_template": MODEL_TEMPLATES[model_type]["template"]}
                )
                output = response.choices[0].message.content
                print(f"文件 {filename} 处理成功")
                success_count += 1
            except Exception as e:
                output = f"处理失败: {str(e)}"
                print(f"文件 {filename} 处理失败: {str(e)}")

            # 保存原始输出
            output_path = os.path.join(model_output_dir, filename)
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(output)

            # 执行评估（仅当成功时）
            if not output.startswith("处理失败"):
                metrics = evaluator.evaluate(output, filename)
                all_metrics[filename] = metrics
                # 打印单个文件的评估结果
                print(f"评估结果: {metrics}")

        # 计算汇总统计
        summary = {
            "total_files": file_count,
            "success_files": success_count,
            "success_rate": success_count / file_count if file_count > 0 else 0
        }

        if all_metrics:
            avg_scores = {k: np.mean([m[k] for m in all_metrics.values()])
                          for k in all_metrics[next(iter(all_metrics))]}
            summary["average_metrics"] = avg_scores

            # 打印汇总统计
            print(f"\n模型 {model_name} 评估汇总：")
            print(f"总文件数: {file_count}, 成功处理: {success_count}, 成功率: {summary['success_rate']:.2%}")
            print("平均指标:")
            for metric, score in avg_scores.items():
                print(f"{metric}: {score:.4f}")
        else:
            summary["average_metrics"] = None
            print("\n没有成功处理的文件，无法计算评估指标")

        # 保存评估结果（包含详细指标和汇总统计）
        metrics_path = os.path.join(output_folder, f"{model_name}_eval.json")
        result_data = {
            "detailed_metrics": all_metrics,
            "summary": summary
        }

        with open(metrics_path, 'w', encoding='utf-8') as f:
            json.dump(result_data, f, indent=2, ensure_ascii=False)

        print(f"\n评估结果已保存到: {metrics_path}")

# ================= 主程序 =================
if __name__ == "__main__":
    # 配置路径
    input_folder = r"D:\研究生\项目组\科研\小模型+RAG暑期实验\50个含教学环节名称的教案\txt教案\测试集\测试集2_删去环节名称并打乱顺序"
    output_folder = r"D:\研究生\项目组\科研\小模型+RAG暑期实验\50个含教学环节名称的教案\txt教案\测试结果\有指标\（增强prompt）测试结果2_删去环节名称并打乱顺序\评估指标5"
    gt_json_path = r"D:\研究生\项目组\科研\小模型+RAG暑期实验\50个含教学环节名称的教案\txt教案\教学环节txt_json\teaching_plan.json"  # 替换为您的标准答案路径

    # 运行处理流程
    batch_process_with_eval(input_folder, output_folder, gt_json_path)