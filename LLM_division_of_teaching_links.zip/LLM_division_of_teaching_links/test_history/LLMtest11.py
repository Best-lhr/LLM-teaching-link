import os
from openai import OpenAI

client = OpenAI(base_url="http://10.154.22.11:8000/v1", api_key="EMPTY")

# ================= 模型配置区域 =================
MODELS = {
    #"DeepSeek-R1": "/home/lhr/7Bmodel/DeepSeek-R1-Distill-Qwen-1.5B",         #model 1
    #"Qwen1.5": "/home/lhr/7Bmodel/Qwen1.5-4B-Chat",                           #model 2
    #"Mistral": "/home/lhr/7Bmodel/Chinese-Mistral-7B-Instruct-v0.1",          #model 3
    #"ChatGLM3": "/home/lhr/7Bmodel/chatglm3-6b",                              #model 4
    #"Baichuan2": "/home/lhr/7Bmodel/Baichuan2-7B-Chat",                       #model 5
    #"InternLM2-5-7B-Chat-1M": "/home/lhr/7Bmodel/internlm2_5-7b-chat-1m",     #model 6
    "MiniCPM3-4B": "/home/lhr/7Bmodel/MiniCPM3-4B",                           #model 7
}

# ================= 原始模板配置（完全未修改）=================
MODEL_TEMPLATES = {
    "deepseek": {
        "template": """
        {% if not add_generation_prompt is defined %}
            {% set add_generation_prompt = false %}
        {% endif %}
        {% set ns = namespace(is_first=false, is_tool=false, is_output_first=true, system_prompt='') %}
        {%- for message in messages %}
            {%- if message['role'] == 'system' %}
                {% set ns.system_prompt = message['content'] %}
            {%- endif %}
        {%- endfor %}
        {{bos_token}}{{ns.system_prompt}}
        {%- for message in messages %}
            {%- if message['role'] == 'user' %}
                {%- set ns.is_tool = false -%}
                {{'### ' + message['content']}}
            {%- endif %}
            {%- if message['role'] == 'assistant' and message['content'] is none %}
                {%- set ns.is_tool = false -%}
                {%- for tool in message['tool_calls']%}
                    {%- if not ns.is_first %}
                        {{'### ' + tool['type'] + '\n' + tool['function']['name'] + '\n```json\n' + tool['function']['arguments'] + '\n```\n'}}
                        {%- set ns.is_first = true -%}
                    {%- else %}
                        {{'\n### ' + tool['type'] + '\n' + tool['function']['name'] + '\n```json\n' + tool['function']['arguments'] + '\n```\n'}}
                        {{'### '}}
                    {%- endif %}
                {%- endfor %}
            {%- endif %}
            {%- if message['role'] == 'assistant' and message['content'] is not none %}
                {%- if ns.is_tool %}
                    {{'### ' + message['content'] + '\n'}}
                    {%- set ns.is_tool = false -%}
                {%- else %}
                    {% set content = message['content'] %}
                    {% if '</think>' in content %}
                        {% set content = content.split('</think>')[-1] %}
                    {% endif %}
                    {{'### ' + content + '\n'}}
                {%- endif %}
            {%- endif %}
            {%- if message['role'] == 'tool' %}
                {%- set ns.is_tool = true -%}
                {%- if ns.is_output_first %}
                    {{'### ' + message['content'] + '\n'}}
                    {%- set ns.is_output_first = false %}
                {%- else %}
                    {{'\n### ' + message['content'] + '\n'}}
                {%- endif %}
            {%- endif %}
        {%- endfor -%}
        {% if ns.is_tool %}
            {{'### '}}
        {% endif %}
        {% if add_generation_prompt and not ns.is_tool %}
            {{'### <think>\n'}}
        {% endif %}
        """,
        "keywords": ["deepseek"],
        "features": {
            "supports_tools": True,
            "requires_system_prompt": False,
            "special_tokens": {
                "bos_token": "<|begin_of_text|>",
                "eos_token": "<|end_of_text|>"
            }
        }
    },
    "qwen": {
        "template": "{% for message in messages %}"
                   "{% if loop.first and messages[0]['role'] != 'system' %}"
                   "{{ '<|im_start|>system\nYou are a helpful assistant.<|im_end|>\n' }}"
                   "{% endif %}"
                   "{{'<|im_start|>' + message['role'] + '\n' + message['content'] + '<|im_end|>' + '\n'}}"
                   "{% endfor %}"
                   "{% if add_generation_prompt %}"
                   "{{ '<|im_start|>assistant\n' }}"
                   "{% endif %}",
        "keywords": ["qwen"],
        "requires_system_prompt": False  # Qwen会自动添加缺省system提示
    },
    "mistral": {
        "template": "{{ bos_token }}"
                    "{% for message in messages %}"
                    "{% if message['role'] == 'user' %}"
                    "{{ '[INST] ' + message['content'] + ' [/INST]' }}"
                    "{% else %}"
                    "{{ message['content'] + eos_token }}"
                    "{% endif %}"
                    "{% endfor %}",
        "keywords": ["mistral"]
    },
    "chatglm": {
        "template": "{% for message in messages %}"
                    "{{'<|im_start|>' + message['role'] + '\n' + message['content'] + '<|im_end|>' + '\n'}}"
                    "{% endfor %}",
        "keywords": ["chatglm"]
    },
    "baichuan": {
        "template": "{{ bos_token }}"
                    "{% for message in messages %}"
                    "{% if message['role'] == 'user' %}"
                    "{{ '<reserved_106>' + message['content'] + '<reserved_107>' }}"
                    "{% else %}"
                    "{{ message['content'] + eos_token }}"
                    "{% endif %}"
                    "{% endfor %}",
        "keywords": ["baichuan"]
    },
    "internlm": {
        "template": "{% for message in messages %}"
                    "<|im_start|>{{message['role']}}\n{{message['content']}}<|im_end|>\n"
                    "{% endfor %}",
        "keywords": ["internlm"]
    },
    "minicpm": {
        "template": "{% for message in messages %}"
                    "<|im_start|>{{message['role']}}\n{{message['content']}}<|im_end|>\n"
                    "{% endfor %}",
        "keywords": ["minicpm"]
    }
}


def detect_model_type(model_path):
    """自动检测模型类型（原逻辑未修改）"""
    model_path = model_path.lower()
    for model_type, config in MODEL_TEMPLATES.items():
        if any(kw in model_path for kw in config["keywords"]):
            return model_type
    return "mistral"


def process_single_file(content, model_path, model_name):
    """处理单个文件（仅修改messages部分）"""
    # 增强版提示词（仅在messages中修改）
    messages = [
        {
            "role": "system",
            "content": "你是一个资深教学设计师，请严格完成以下任务：\n"
                       "1. 识别教案中的所有教学环节\n"
                       "2. 对每个环节必须输出：【环节名称】和对应的完整教学内容\n"
                       "3. 保持内容原封不动，仅添加环节标记\n\n"
                       "输出格式要求：\n"
                       "【环节名称】\n"
                       "该环节的完整内容（包括所有文字、标点等原始内容）\n\n"
                       "示例：\n"
                       "【课堂导入】\n"
                       "同学们，今天我们学习...（此处为完整的导入部分内容）"
        },
        {
            "role": "user",
            "content": f"请分析以下教案并划分教学环节（严格按上述要求输出）：\n{content}"
        }
    ]

    model_type = detect_model_type(model_path)
    extra_body = {"chat_template": MODEL_TEMPLATES[model_type]["template"]}

    try:
        response = client.chat.completions.create(
            model=model_path,
            messages=messages,
            temperature=0.3,
            max_tokens=2048,
            extra_body=extra_body
        )
        return response.choices[0].message.content
    except Exception as e:
        return f"处理失败: {str(e)}"


def batch_process_files(input_folder, output_folder):
    """批量处理文件（原逻辑未修改）"""
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    for model_name, model_path in MODELS.items():
        print(f"\n=== 开始测试模型: {model_name} ===")
        model_output_dir = os.path.join(output_folder, model_name)
        os.makedirs(model_output_dir, exist_ok=True)

        for filename in sorted(os.listdir(input_folder)):
            if filename.endswith('.txt'):
                input_path = os.path.join(input_folder, filename)
                output_path = os.path.join(model_output_dir, filename)

                with open(input_path, 'r', encoding='utf-8') as f:
                    content = f.read().strip()

                print(f"正在处理: {filename}")
                result = process_single_file(content, model_path, model_name)

                with open(output_path, 'w', encoding='utf-8') as f:
                    f.write(f"=== 模型: {model_name} ===\n")
                    f.write(f"=== 文件: {filename} ===\n\n")
                    f.write(result + "\n")

        print(f"=== 模型 {model_name} 测试完成 ===")


if __name__ == "__main__":
    input_folder = r"D:\研究生\项目组\科研\小模型+RAG暑期实验\50个含教学环节名称的教案\txt教案\测试集\测试集1_删去环节名称"  # 无环节标记的教案
    output_folder = r"D:\研究生\项目组\科研\小模型+RAG暑期实验\50个含教学环节名称的教案\txt教案\测试结果\无指标\（增强prompt）测试结果2_删去环节名称"  # 结果输出目录
    batch_process_files(input_folder, output_folder)