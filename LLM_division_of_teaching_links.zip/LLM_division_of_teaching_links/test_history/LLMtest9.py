from openai import OpenAI

client = OpenAI(base_url="http://10.154.22.11:8000/v1", api_key="EMPTY")

# ================= 模型配置区域 =================
# 只需取消注释要使用的模型：
MODELS = {
    #"DeepSeek-R1": "/home/lhr/7Bmodel/DeepSeek-R1-Distill-Qwen-1.5B",
    #"Qwen1.5": "/home/lhr/7Bmodel/Qwen1.5-4B-Chat",
    # "Mistral": "/home/lhr/7Bmodel/Chinese-Mistral-7B-Instruct-v0.1",
    # "ChatGLM3": "/home/lhr/7Bmodel/chatglm3-6b",
    # "Baichuan2": "/home/lhr/7Bmodel/Baichuan2-7B-Chat",
    #"InternLM2-5-7B-Chat-1M": "/home/lhr/7Bmodel/internlm2_5-7b-chat-1m",
    "MiniCPM3-4B": "/home/lhr/7Bmodel/MiniCPM3-4B",
}
MODEL_PATH = list(MODELS.values())[0]  # 默认使用第一个启用的模型

# ================= 模型模板配置 =================
MODEL_TEMPLATES = {
    # DeepSeek (基于Qwen)
    "deepseek": {
        "template": "{% for message in messages %}"
                    "<|im_start|>{{message['role']}}\n{{message['content']}}<|im_end|>\n"
                    "{% endfor %}",
        "keywords": ["deepseek", "distill-qwen"]
    },
    # Qwen系列
    "qwen": {
        "template": "{% for message in messages %}"
                   "{% if loop.first and messages[0]['role'] != 'system' %}"
                   "{{ '<|im_start|>system\nYou are a helpful assistant.<|im_end|>\n' }}"
                   "{% endif %}"
                   "{{'<|im_start|>' + message['role'] + '\n' + message['content'] + '<|im_end|>' + '\n'}}"
                   "{% endfor %}"
                   "{% if add_generation_prompt %}"
                   "{{ '<|im_start|>assistant\n' }}"
                   "{% endif %}",
        "keywords": ["qwen"],
        "requires_system_prompt": False  # Qwen会自动添加缺省system提示
    },
    # Gemma系列
    "gemma": {
        "template": "{{ bos_token }}"
                    "{% for message in messages %}"
                    "{{ '<start_of_turn>' + message['role'] + '\n' + message['content'] + '<end_of_turn>\n' }}"
                    "{% endfor %}",
        "keywords": ["gemma"]
    },
    # Mistral系列
    "mistral": {
        "template": "{{ bos_token }}"
                    "{% for message in messages %}"
                    "{% if message['role'] == 'user' %}"
                    "{{ '[INST] ' + message['content'] + ' [/INST]' }}"
                    "{% else %}"
                    "{{ message['content'] + eos_token }}"
                    "{% endif %}"
                    "{% endfor %}",
        "keywords": ["mistral"]
    },
    # ChatGLM系列
    "chatglm": {
        "template": "{% for message in messages %}"
                    "{{'<|im_start|>' + message['role'] + '\n' + message['content'] + '<|im_end|>' + '\n'}}"
                    "{% endfor %}",
        "keywords": ["chatglm"]
    },
    # Baichuan系列
    "baichuan": {
        "template": "{{ bos_token }}"
                    "{% for message in messages %}"
                    "{% if message['role'] == 'user' %}"
                    "{{ '<reserved_106>' + message['content'] + '<reserved_107>' }}"
                    "{% else %}"
                    "{{ message['content'] + eos_token }}"
                    "{% endif %}"
                    "{% endfor %}",
        "keywords": ["baichuan"]
    },
    # Llama系列
    "llama": {
        "template": "{% if messages[0]['role'] == 'system' %}"
                    "{{ '<s>[INST] <<SYS>>\n' + messages[0]['content'] + '\n<</SYS>>\n\n' }}"
                    "{% else %}"
                    "{{ '<s>[INST] ' + messages[0]['content'] + ' [/INST]' }}"
                    "{% endif %}"
                    "{% for message in messages[1:] %}"
                    "{% if message['role'] == 'user' %}"
                    "{{ '[INST] ' + message['content'] + ' [/INST]' }}"
                    "{% else %}"
                    "{{ message['content'] + '</s>' }}"
                    "{% endif %}"
                    "{% endfor %}",
        "keywords": ["llama"]
    },
    # InternLM2系列
    "internlm": {
        "template": "{% for message in messages %}"
                    "<|im_start|>{{message['role']}}\n{{message['content']}}<|im_end|>\n"
                    "{% endfor %}",
        "keywords": ["internlm"]
    },
    # MiniCPM3系列
    "minicpm": {
        "template": "{% for message in messages %}"
                    "<|im_start|>{{message['role']}}\n{{message['content']}}<|im_end|>\n"
                    "{% endfor %}",
        "keywords": ["minicpm"]
    },
    # XVERSE系列
    "xverse": {
        "template": "{% for message in messages %}"
                    "{{'<|im_start|>' + message['role'] + '\n' + message['content'] + '<|im_end|>' + '\n'}}"
                    "{% endfor %}",
        "keywords": ["xverse"]
    }
}


# ================= 核心功能 =================
def detect_model_type(model_path):
    model_path = model_path.lower()
    for model_type, config in MODEL_TEMPLATES.items():
        if any(kw in model_path for kw in config["keywords"]):
            return model_type
    return "default"  # 保底使用通用模板


def print_available_models():
    print("\n可用模型列表：")
    for i, (name, path) in enumerate(MODELS.items(), 1):
        print(f"{i}. {name} ({'已启用' if path == MODEL_PATH else '未启用'})")


# ================= 主程序 =================
if __name__ == "__main__":
    print_available_models()

    # 获取用户输入
    user_input = input("\n请粘贴完整教案：\n").strip()
    if not user_input:
        print("错误：教案内容不能为空！")
        exit()

    # # 构造对话消息
    # messages = [
    #     {"role": "system", "content": "你是一个资深教学设计专家，请清晰划分教学环节"},
    #     {"role": "user", "content": f"请分析以下教案并划分明确的教学步骤：\n{user_input}"}
    # ]

    messages = [
        {
            "role": "system",
            "content": "你是一个资深教学设计师，请严格完成以下任务：\n"
                       "1. 识别教案中的所有教学环节\n"
                       "2. 对每个环节必须输出：【环节名称】和对应的完整教学内容\n"
                       "3. 保持内容原封不动，仅添加环节标记\n\n"
                       "输出格式要求：\n"
                       "【环节名称】\n"
                       "该环节的完整内容（包括所有文字、标点等原始内容）\n\n"
                       "示例：\n"
                       "【课堂导入】\n"
                       "同学们，今天我们学习...（此处为完整的导入部分内容）"
        },
        {
            "role": "user",
            "content": f"请分析以下教案并划分教学环节（严格按上述要求输出）：\n{user_input}"
        }
    ]

    # 自动适配模型
    model_type = detect_model_type(MODEL_PATH)
    extra_body = {"chat_template": MODEL_TEMPLATES.get(model_type, MODEL_TEMPLATES["mistral"])["template"]}

    print(f"\n正在使用模型: {list(MODELS.keys())[list(MODELS.values()).index(MODEL_PATH)]}")
    print(f"自动选择模板: {model_type}")

    try:
        response = client.chat.completions.create(
            model=MODEL_PATH,
            messages=messages,
            temperature=0.3,
            max_tokens=2048,
            extra_body=extra_body
        )
        print("\n=== 教学环节划分 ===")
        print(response.choices[0].message.content)
        print("=" * 30)

    except Exception as e:
        print(f"\n错误：{str(e)}")
        if hasattr(e, 'response'):
            print("服务端返回：", e.response.text)
        print("\n调试建议：")
        print("1. 检查模型服务是否正常运行")
        print("2. 尝试其他模型路径")
        print("3. 查看模板是否匹配当前模型")