from openai import OpenAI
import time

# 配置客户端
client = OpenAI(
    base_url="http://10.154.22.11:8000/v1",  # 替换为你的服务器IP
    api_key="sk-xxx"  # 任意字符串
)

# 初始化对话
messages = [
    {"role": "system", "content": "你是一个乐于助人的AI助手。"}
]

# 超时设置（秒）
TIMEOUT = 30  # 30秒无输入自动退出
last_active = time.time()

print("欢迎使用 DeepSeek 聊天助手！输入 'exit' 退出。")

while True:
    # 检查超时
    if time.time() - last_active > TIMEOUT:
        print("\n长时间无输入，会话已结束。")
        break

    # 获取用户输入（禁止空内容）
    try:
        user_input = input("\n用户: ").strip()
        last_active = time.time()  # 重置活跃时间戳

        if user_input.lower() == "exit":
            print("会话结束。")
            break
        if not user_input:
            print("输入不能为空！")
            continue

        # 发送请求
        messages.append({"role": "user", "content": user_input})
        response = client.chat.completions.create(
            #model="/home/lhr/7Bmodel/DeepSeek-R1-Distill-Qwen-1.5B",
            model="/home/lhr/7Bmodel/Qwen1.5-4B-Chat",
            messages=messages,
            temperature=0.7,
            max_tokens=1024,
            stream=True  # 流式输出
        )

        # 流式打印AI回复
        print("AI助手: ", end="", flush=True)
        full_response = []
        for chunk in response:
            text = chunk.choices[0].delta.content or ""
            print(text, end="", flush=True)
            full_response.append(text)
        print()

        # 保存完整回复到历史
        messages.append({"role": "assistant", "content": "".join(full_response)})

    except KeyboardInterrupt:
        print("\n用户强制退出。")
        break
    except Exception as e:
        print(f"\n发生错误: {str(e)}")
        break