from openai import OpenAI
import time

timeout = 30  # 30秒无输入自动退出
last_active = time.time()

# 配置客户端（连接你的 vLLM 服务器）
client = OpenAI(
    base_url="http://10.154.22.11:8000/v1",  # 替换为你的服务器IP
    api_key="sk-xxx"  # 任意字符串绕过检查
)

# 初始化对话历史
messages = [
    {"role": "system", "content": "你是一个乐于助人的AI助手。"}
]

print("欢迎使用 DeepSeek 聊天助手！输入 'exit' 退出。")

while True:
    # 用户输入
    user_input = input("\n用户: ")
    if user_input.lower() == "exit":
        break

    # 添加用户消息到历史
    messages.append({"role": "user", "content": user_input})

    # 调用 vLLM API
    response = client.chat.completions.create(
        model="/home/lhr/7Bmodel/DeepSeek-R1-Distill-Qwen-1.5B",  # 你的模型路径
        messages=messages,
        temperature=0.7,  # 控制随机性 (0~1)
        max_tokens=1024    # 限制生成长度
    )

    # 获取AI回复
    ai_response = response.choices[0].message.content
    print(f"\nAI助手: {ai_response}")

    # 添加AI回复到历史
    messages.append({"role": "assistant", "content": ai_response})