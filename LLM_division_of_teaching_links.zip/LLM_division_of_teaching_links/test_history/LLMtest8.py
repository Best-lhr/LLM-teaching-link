from openai import OpenAI

# 配置客户端
client = OpenAI(
    base_url="http://10.154.22.11:8000/v1",
    api_key="EMPTY"
)

# 模型路径（确保路径正确）
MODEL_PATH = "/home/lhr/7Bmodel/chatglm3-6b"

# 获取用户输入
user_input = input("请粘贴完整教案：\n").strip()
if not user_input:
    print("错误：教案内容不能为空！")
    exit()

# 构造聊天格式（适配ChatGLM3）
messages = [
    {"role": "system", "content": "你是一个资深教学设计专家，请根据教案内容划分教学环节。"},
    {"role": "user", "content": f"请划分以下教案的教学环节：\n\n{user_input}"}
]

# 强制指定聊天模板（关键修复！）
extra_body = {
    "chat_template": "{% for message in messages %}"
                    "{{'<|im_start|>' + message['role'] + '\n' + message['content'] + '<|im_end|>' + '\n'}}"
                    "{% endfor %}"
}

try:
    response = client.chat.completions.create(
        model=MODEL_PATH,
        messages=messages,
        temperature=0.3,
        max_tokens=1024,
        extra_body=extra_body  # 传递自定义模板
    )
    result = response.choices[0].message.content
    print("\n=== 划分结果 ===\n" + result)

except Exception as e:
    print(f"发生错误：{str(e)}")
    if hasattr(e, 'response'):
        print("详细错误：", e.response.text)