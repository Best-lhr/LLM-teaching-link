# -*- coding: utf-8 -*-
from transformers import AutoModelForCausalLM, AutoTokenizer


def load_model(model_path):
    tokenizer = AutoTokenizer.from_pretrained(model_path)
    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        torch_dtype="auto",
        device_map="auto"
    )
    return tokenizer, model


def get_teaching_phases(content, tokenizer, model):
    prompt = f"""请将以下教案内容划分为教学环节，只需输出划分结果，不要任何解释和额外符号：

{content}

教学环节划分："""

    inputs = tokenizer(prompt, return_tensors="pt").to("cuda")
    outputs = model.generate(
        **inputs,
        max_new_tokens=500,
        temperature=0.3
    )

    return tokenizer.decode(outputs[0], skip_special_tokens=True).replace(prompt, "").strip()


if __name__ == "__main__":
    model_path = "/home/lhr/7Bmodel/Qwen1.5-4B-Chat"
    #model_path = "/home/lhr/7Bmodel/DeepSeek-R1-Distill-Qwen-1.5B"
    #model_path = "/home/lhr/7Bmodel/Llama-3.2-3B"
    tokenizer, model = load_model(model_path)

    print("请输入教案内容（输入空行回车结束输入）：")
    content_lines = []
    while True:
        line = input()
        if line.strip() == "":
            break
        content_lines.append(line)

    content = "\n".join(content_lines)
    phases = get_teaching_phases(content, tokenizer, model)
    print("\n教学环节划分：")
    print(phases)