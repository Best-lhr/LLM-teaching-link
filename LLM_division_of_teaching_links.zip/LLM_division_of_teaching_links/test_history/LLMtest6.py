from openai import OpenAI

# 设置客户端（使用 completions 接口）
client = OpenAI(base_url="http://10.154.22.11:8000/v1", api_key="EMPTY")

# 用户输入教案内容
user_input = input("请粘贴完整教案：\n").strip()

if not user_input:
    print("错误：教案内容不能为空！")
else:
    # 构造 prompt
    prompt = f"""你是一个资深教学设计专家，请根据我提供的完整教案内容，按照逻辑顺序将其划分为若干明确的教学环节。

请以编号方式列出每个教学环节，并简要说明该环节的目标和主要活动。

教案内容：
{user_input}

教学环节划分结果：
"""

    # 使用 completions 接口，不会触发 chat template 报错
    response = client.completions.create(
        # model="/home/lhr/7Bmodel/gemma-2-2b",
        # model="/home/lhr/7Bmodel/gemma-3-4b-it",
        model="/home/lhr/7Bmodel/Chinese-Mistral-7B-Instruct-v0.1",
        prompt=prompt,
        temperature=0.3,
        max_tokens=1024,
        stop=[],  # 防止提前停止生成
        echo=False
    )

    # 输出结果
    print("\n教学环节划分结果：")
    print(response.choices[0].text.strip())