# TeachingRAGOrchestrator.py 修改版
import logging
import joblib
import time
import re
from typing import List, Dict, Literal, Tuple
from fuzzywuzzy import fuzz
from SegmentTeachingRAG import SegmentTeachingRAG
from macro_retriever import MacroTemplateRetriever

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class TeachingRAGOrchestrator:
    """
    智能路由 RAG：ST-RAG + macro-RAG 动态融合（基于内容覆盖验证）
    只有当宏观模板的环节在微观检索结果中有足够覆盖时才使用宏观顺序提示
    """

    def __init__(
            self,
            encoder_url: str = "http://10.154.22.11:9000",
            reranker_url: str = "http://10.154.22.11:9001",
            macro_template_path: str = "macro_template.jsonl",
            mode_clf_path: str = r"D:\Python\PythonProject\LLM_division_of_teaching_links\分类模型\无环节乱序训练\k邻近\teachingmode_classifier_cls.pkl",
            type_clf_path: str = r"D:\Python\PythonProject\LLM_division_of_teaching_links\分类模型\无环节乱序训练\k邻近\lessontype_classifier_cls.pkl",
            concept_clf_path: str = r"D:\Python\PythonProject\LLM_division_of_teaching_links\分类模型\无环节乱序训练\k邻近\coreconcept_classifier_cls.pkl",
            kb_dir: str = r"D:\研究生\项目组\科研\小模型+RAG暑期实验\RAG知识库_3",
            default_threshold: float = 0.6  # 默认覆盖率阈值（0-1）
    ):
        # 1. 微观 RAG
        self.rags = {
            "segment": SegmentTeachingRAG(
                kb_dir=kb_dir,
                encoder_url=encoder_url,
                reranker_url=reranker_url
            )
        }

        # 2. 宏观模板检索器
        self.macro_retriever = MacroTemplateRetriever(
            template_path=macro_template_path,
            encoder_url=encoder_url
        )

        # 3. 加载三分类器
        self.mode_clf = joblib.load(mode_clf_path)
        self.type_clf = joblib.load(type_clf_path)
        self.concept_clf = joblib.load(concept_clf_path)

        self.default_threshold = default_threshold

        logger.info("RAG系统初始化完成（基于内容覆盖的动态验证）")

    def _extract_segment_names(self, segment_text: str) -> List[str]:
        """
        从ST-RAG检索结果中提取教学环节名称（去重，无视顺序）
        支持格式：【环节名称】、环节名称：
        """
        # 匹配【XXX】格式
        pattern_bracket = r'【(.+?)】'
        # 匹配 "环节名称：" 格式
        pattern_colon = r'^([\u4e00-\u9fa5]{2,8})[：:]'

        segments = []

        # 提取方括号中的
        brackets = re.findall(pattern_bracket, segment_text)
        segments.extend([s.strip() for s in brackets])

        # 提取冒号前的（如果还没被提取）
        lines = segment_text.split('\n')
        for line in lines:
            match = re.match(pattern_colon, line.strip())
            if match:
                name = match.group(1)
                if name not in segments:
                    segments.append(name)

        # 清洗：统一同义词
        cleaned = self._normalize_segment_names(segments)
        return cleaned

    def _normalize_segment_names(self, names: List[str]) -> List[str]:
        """
        标准化环节名称，统一同义词，返回去重后的列表
        """
        synonyms = {
            "导入": ["导入", "课堂导入", "新课导入", "引入", "情境导入", "创设情境"],
            "讲解": ["讲解", "新授", "讲授", "知识讲解", "新知讲解", "探究", "自主探究", "合作探究"],
            "练习": ["练习", "操练", "巩固练习", "课堂练习", "应用练习", "运用模型", "解决问题"],
            "总结": ["总结", "课堂总结", "归纳", "小结", "课堂小结"],
            "作业": ["作业", "课后作业", "布置作业", "课外作业", "巩固提升"],
            "复习": ["复习", "课前复习", "知识回顾", "温故知新", "复习引入"],
            "提问": ["提问", "问题导入", "设问", "呈现问题", "引出探究"],
            "实际操作": ["实际操作", "动手操作", "实践操作", "摆一摆"],
        }

        normalized = []
        for name in names:
            found = False
            for standard, variants in synonyms.items():
                if any(v in name for v in variants) or name in variants:
                    if standard not in normalized:  # 去重
                        normalized.append(standard)
                    found = True
                    break
            if not found and name not in normalized:
                normalized.append(name)  # 保留原始名称（去重）
        return normalized

    def _calculate_coverage(
            self,
            segment_result: str,
            macro_order: List[str]
    ) -> Tuple[float, List[str], List[str], List[Tuple[str, str, int]]]:
        """
        计算宏观模板的环节在ST-RAG检索结果中的覆盖率（基于模糊匹配）

        返回：
            - coverage: 覆盖率 0-1（匹配的宏观环节数 / 总宏观环节数）
            - matched_macros: 已匹配的宏观环节列表
            - unmatched_macros: 未匹配的宏观环节列表
            - match_details: 匹配详情 [(宏观环节, 匹配的微观环节, 相似度分数), ...]
        """
        if not macro_order:
            return 0.0, [], [], []

        # 1. 从ST-RAG提取环节（去重，无序）
        micro_segments = self._extract_segment_names(segment_result)

        # 2. 标准化宏观模板（去重，但保持原顺序用于调试）
        macro_normalized = self._normalize_segment_names(macro_order)
        macro_set = list(dict.fromkeys(macro_normalized))  # 去重但保持顺序

        if not micro_segments:
            return 0.0, [], macro_set, []

        # 3. 逐一检查每个宏观环节是否在微观结果中有匹配
        matched_macros = []
        unmatched_macros = []
        match_details = []

        for macro_seg in macro_set:
            best_match = None
            best_score = 0
            best_micro = None

            # 在微观环节中找最佳匹配
            for micro_seg in micro_segments:
                # 使用partial_ratio处理包含关系（如"自主探究"匹配"探究"）
                score = fuzz.partial_ratio(macro_seg, micro_seg)
                if score > best_score:
                    best_score = score
                    best_micro = micro_seg

            # 阈值设定：相似度>=60认为匹配（可根据数据调整）
            if best_score >= 60:
                matched_macros.append(macro_seg)
                match_details.append((macro_seg, best_micro, best_score))
            else:
                unmatched_macros.append(macro_seg)
                match_details.append((macro_seg, "未匹配", best_score))

        # 4. 计算覆盖率（召回率）
        coverage = len(matched_macros) / len(macro_set) if macro_set else 0.0

        return coverage, matched_macros, unmatched_macros, match_details

    def _should_use_macro_template(
            self,
            segment_result: str,
            macro_order: List[str],
            threshold: float = None
    ) -> Tuple[bool, float, str]:
        """
        判断是否应使用宏观模板作为提示（基于内容覆盖验证）
        返回：(是否使用, 覆盖率, 决策理由)
        """
        if threshold is None:
            threshold = self.default_threshold

        if not macro_order:
            return False, 0.0, "宏观模板为空"

        # 计算覆盖率
        coverage, matched, unmatched, details = self._calculate_coverage(
            segment_result, macro_order
        )

        # 调试信息：打印匹配详情
        logger.debug(f"匹配详情: {details}")
        print(f"[匹配验证] 宏观环节共{len(macro_order)}个，ST-RAG提取到{len(self._extract_segment_names(segment_result))}个")
        print(f"[匹配验证] 已匹配: {matched}")
        print(f"[匹配验证] 未匹配: {unmatched}")
        print(f"[匹配验证] 覆盖率: {coverage:.2f} (阈值: {threshold})")

        # 决策逻辑：覆盖率>=阈值则认为模板可信
        if coverage >= threshold:
            reason = f"覆盖率{coverage:.2f}高于阈值{threshold}，宏观模板与检索内容匹配，使用宏观顺序"
            return True, coverage, reason
        else:
            reason = f"覆盖率{coverage:.2f}低于阈值{threshold}，分类器可能预测错误，放弃宏观模板"
            return False, coverage, reason

    def process(
            self,
            query: str,
            mode: Literal["segment"] = "segment",
            enable_dynamic_filter: bool = True,
            coverage_threshold: float = None
    ) -> Tuple[str, str, bool, float]:
        """
        处理流程，增加基于覆盖率的动态验证

        返回：
            - segment_result: ST-RAG检索结果
            - macro_hint: 宏观顺序提示（若验证不通过则返回空字符串或ST-RAG提取的顺序）
            - used_macro: 是否使用了宏观模板
            - coverage: 覆盖率（置信度指标，0-1）
        """
        if mode not in self.rags:
            raise ValueError(f"不支持的RAG模式: {mode}")

        # 1. 三分类器预测（用于检索宏观模板）
        mode_pred = self.mode_clf.predict([query])[0]
        type_pred = self.type_clf.predict([query])[0]
        concept_pred = self.concept_clf.predict([query])[0]

        # 2. 获取宏观模板
        macro_tpl = self.macro_retriever.retrieve_exact(mode_pred, type_pred, concept_pred)
        macro_order = macro_tpl.get("教学环节及其顺序", [])

        # 3. ST-RAG微观检索
        start = time.time()

        # 注意：这里先不带宏观先验进行检索，避免ST-RAG被错误的宏观顺序污染
        # 如果希望带先验，可以把macro_prior加回来
        segment_result = self.rags[mode].retrieve(query, macro_prior=None)

        logger.info(f"ST-RAG完成，耗时 {time.time() - start:.2f} 秒")

        # 4. 基于覆盖率的动态验证
        used_macro = False
        confidence = 0.0
        macro_hint = ""

        if enable_dynamic_filter and macro_order:
            should_use, confidence, reason = self._should_use_macro_template(
                segment_result, macro_order, coverage_threshold
            )
            logger.info(f"[动态路由] {reason}")
            print(f"[动态路由] {reason}")

            if should_use:
                macro_hint = " -> ".join(macro_order)
                used_macro = True
            else:
                # 不使用宏观模板，降级为使用ST-RAG实际提取的顺序作为弱参考
                extracted = self._extract_segment_names(segment_result)
                macro_hint = " -> ".join(extracted) if extracted else ""
                used_macro = False
        else:
            # 不使用动态过滤，直接返回宏观模板
            macro_hint = " -> ".join(macro_order) if macro_order else ""
            used_macro = bool(macro_order)
            # 即使不使用动态过滤，也计算一下覆盖率供参考
            if macro_order:
                conf, _, _, _ = self._calculate_coverage(segment_result, macro_order)
                confidence = conf

        return segment_result, macro_hint, used_macro, confidence

    # ------------------ 供实验调参 ------------------
    def update_threshold(self, new_threshold: float):
        """动态调整覆盖率阈值"""
        self.default_threshold = new_threshold
        logger.info(f"覆盖率阈值已更新为: {new_threshold}")

    def make_segment_rag(self, k_i: int, k_f: int, use_vector: bool = True, use_rerank: bool = True):
        """创建自定义参数的RAG实例"""
        return SegmentTeachingRAG(
            kb_dir=self.rags["segment"].kb_dir,
            encoder_url=self.rags["segment"].encoder_url,
            reranker_url=self.rags["segment"].reranker_url,
            top_k_initial=k_i,
            top_k_final=k_f,
            use_vector=use_vector,
            use_rerank=use_rerank
        )