LLMtest6为LLMtest4_gemma的改版程序，将函数定义取消了。
LLMtest4_gemma内涵3个不用chat的函数client.completions.create，实现接口与LLMtest4中的client.chat.completions.create稍有不同。
LLMtest7为万能模板。



******
LLMtest9为7的优化版，删除了性能差的模型，选取了性能好的模型。(单次教案测验)******
******



******
LLMtest10为对处理好的txt进行教学环节的划分，1识别出教学环节名称 2.划分出每个环节对应下的完整内容。（多次教案测验，无指标）******
******



LLMtest11为LLMtest10的提示词prompt增强版，在message处修改。
LLMtest_evaluate在11的基础上加入了评估指标。参考答案为teaching_plan.json，但少了在输出框print每个文件的功能。
LLMtest_evaluate1在LLMtest_evaluate的基础上把逐个文件print出来的功能恢复，然后在输出的json文件增多了一个评估汇总。



******
LLMtest_evaluate5为最新版本，但评估指标还有待优化。（多次教案测验，有指标）
******



LLMtest_eavluate6的提示词增加了让小模型复原打乱教案顺序的提示，对应的是删除和打乱环节名称的数据集。而5只是对应删除环节名称的数据集。
LLMtest_evaluate7在6的基础上把4个无关紧要的指标删了，新增了环节边界F1和环节名称规范性两个指标，共有4个指标，保留了内容完整性和顺序合理性。



******
LLMtest_evaluate8在7的基础上对环节边界的判定标准进行了优化。顺序合理性在当预测文本或标准答案文本为空时（if not pred_texts or not gt_texts）、
当TF-IDF向量化过程中出现异常时（except部分）、当只有一个环节时（if len(matched_indices) > 1 else 0.5），把0.5改为0，合理评分。
（多次教案测验，针对删去环节和乱序，有指标）
******



******
注：后续对于Deepseek-R1-1.5B、Qwen3-4B、internlm2_5-7b-chat-1m、MiniCPM3-4B可以用LLMtest_evaluate8.py即是默认设置进行实验。
MiniCPM3-4B、Deepseek7b也可以用LLMtest_evaluate9.py即是默认设置相反进行实验。
对于Qwen1.5-4B-chat、Chinese-Mistral-7B-Instruct-v0.1、chatglm3-6b、
Baichuan2-7B-Chat、internlm2_5-7b-chat-1m可以使用LLMtest_evaluate10.py进行实验
******
